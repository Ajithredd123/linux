#include<stdio.h>
#include<pthread.h>
void *fun(void *args)
{
	char *p = (char *)args;
	printf("entered name : %s\n",p);
}
int main()
{
	char name[50];
	pthread_t tid;
	printf("enter the name : ");
	scanf("%s", name);
	pthread_create(&tid,NULL,fun,name);
	pthread_join(tid,NULL);
	return 0;
}
