#include<stdio.h>
#include<pthread.h>
void *fun(void *args)
{
	char *p=(char *)args;
	int count=0;
	for(int i=0;i<p[i]!= '\0';i++){
	if(p[i]=='a' || p[i]=='e' || p[i]=='i' || p[i]=='o' || p[i]=='u' || p[i]=='A' || p[i]=='E' || p[i]=='I' || p[i]=='O' || p[i]=='U'){
	count++;
}
}
	printf("no.of vowles = %d\n",count);
}
int main()
{
	pthread_t tid;
	char n[50];
	printf("enter the character : ");
	scanf("%s",n);
	pthread_create(&tid,NULL,fun,n);
	pthread_join(tid,NULL);
	return 0;
}
