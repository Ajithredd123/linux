#include<stdio.h>
#include<pthread.h>
void *fun(void *args)
{
	int n = *(int *)args;
	int fact=1;
	for(int i=1;i<=n;i++){
	fact=fact*i;
}
	printf("fact = %d",fact);
}
int main()
{
	pthread_t tid;
	int num;
	printf("enter the number : ");
	scanf("%d",&num);
	pthread_create(&tid,NULL,fun,&num);
	pthread_join(tid,NULL);
	return 0;
}
