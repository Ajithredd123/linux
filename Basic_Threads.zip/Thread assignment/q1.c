#include<stdio.h>
#include<pthread.h>
void fun(void * args){
	printf("hello from thread\n");
}
int main()
{
        pthread_t tid;
        pthread_create(&tid,NULL,fun,NULL);
	printf("hello from main fun\n");
	pthread_join(tid,NULL);
	return 0;
}
