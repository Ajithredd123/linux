#include<stdio.h>
#include<pthread.h>
void *fun1(void *args)
{
	for(int i=0;i<100;i++){
	printf("thread1 = %d\n",i);
}
}
void *fun2(void *args)
{
	for(int i=0;i<100;i++){
	printf("thread2 = %d\n",i);
}
}
int main()
{
	pthread_t tid1;
	pthread_t tid2;
	pthread_create(&tid1,NULL,fun1,NULL);
	pthread_create(&tid2,NULL,fun2,NULL);
	pthread_join(tid1,NULL);
	pthread_join(tid2,NULL);
	return 0;
}
