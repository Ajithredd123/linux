#include<stdio.h>
#include<pthread.h>
int count = 0;
void *fun1(void *args)
{
        for(int i=1;i<1000;i++){
	count++;
}
}
void *fun2(void *args)
{
        for(int i=1;i<100;i++){
	count--;
}
}
int main()
{
        pthread_t tid1;
        pthread_t tid2;
        pthread_create(&tid1,NULL,fun1,NULL);
        pthread_create(&tid2,NULL,fun2,NULL);
        pthread_join(tid1,NULL);
        pthread_join(tid2,NULL);
	printf("Count = %d\n", count);
        return 0;
}
