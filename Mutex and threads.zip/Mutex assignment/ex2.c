#include<stdio.h>
#include<pthread.h>
int count=0;
void *fun1(void *args)
{ 
     int p= *(int*)args;
        for(int p=0;p<100;p++){
	count++;
        printf("printing from fun1 thread %d\n",count);
           }
        }
void *fun2(void *args)
{
        int p= *(int*)args;
        for(int p=0;p<100;p++){
	count--;
        printf("printing from fun2 thread %d\n",count);
           }
        }

int main()
{
        pthread_t tid1,tid2;
        int p=100;
        pthread_create(&tid1,NULL,fun1,&p);
	pthread_create(&tid2,NULL,fun2,&p);
        /*for(int i=0;i<100;i++){
                printf("printing from main thread %d\n",i);
        }*/
        pthread_join(tid1,NULL);
	pthread_join(tid1,NULL);
        return 0;
}
