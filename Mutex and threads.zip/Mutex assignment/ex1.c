#include<stdio.h>
#include<pthread.h>
void *fun1(void *args)
{
	int p= *(int*)args;
	for(int p=0;p<100;p++){
	printf("printing from fun1 thread %d\n",p);
	   }
	}
int main()
{
	pthread_t tid1;
	int p=100;
	pthread_create(&tid1,NULL,fun1,&p);
	for(int i=0;i<100;i++){
		printf("printing from main thread %d\n",i);
	}
	pthread_join(tid1,NULL);
	return 0;
}
