#include<stdio.h>
#include<pthread.h>
int count = 0;
pthread_mutex_t key;
void *fun1(void *args)
{
        for(int i=1;i<50;i++){
	pthread_mutex_lock(&key);
	count++;
	printf("Count = %d\n", count);
	pthread_mutex_unlock(&key);
}
}
void *fun2(void *args)
{
        for(int i=1;i<50;i++){
	pthread_mutex_lock(&key);
	count--;
	printf("Count = %d\n", count);
	pthread_mutex_unlock(&key);
}
}
int main()
{
        pthread_t tid1;
        pthread_t tid2;
	pthread_mutex_init(&key,NULL);
        pthread_create(&tid1,NULL,fun1,NULL);
        pthread_create(&tid2,NULL,fun2,NULL);
        pthread_join(tid1,NULL);
        pthread_join(tid2,NULL);
        return 0;
}
