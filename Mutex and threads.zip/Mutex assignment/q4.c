#include<stdio.h>
#include<pthread.h>
#include<semaphore.h>
#include<unistd.h>
sem_t key;
void *fun1(void *args)
{
     	sem_wait(&key);
        for(int i=1;i<50;i++){
        printf("thread 1 - Iteration = %d\n", i);
	sleep(1);
}
        sem_post(&key);
	return NULL;

}
void *fun2(void *args)
{
        sem_wait(&key);
        for(int i=1;i<50;i++){
        printf("thread 2 - Iteration = %d\n", i);
	sleep(1);
}
        sem_post(&key);
	return NULL;
}
void *fun3(void *args)
{
        sem_wait(&key);
        for(int i=1;i<50;i++){
        printf("thread 3 - Iteration = %d\n", i);
	sleep(1);
} 
        sem_post(&key);
	return NULL;
   
}

int main()
{
        pthread_t tid1;
        pthread_t tid2;
	pthread_t tid3;
        sem_init(&key,0,3);
        pthread_create(&tid1,NULL,fun1,NULL);
        pthread_create(&tid2,NULL,fun2,NULL);
 	pthread_create(&tid3,NULL,fun3,NULL);
        pthread_join(tid1,NULL);
        pthread_join(tid2,NULL);
        pthread_join(tid3,NULL);
        return 0;
}
